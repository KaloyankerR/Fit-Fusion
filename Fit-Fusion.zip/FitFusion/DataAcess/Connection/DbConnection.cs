﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcess.Connection
{
    public class DbConnection
    {
        // TODO: Need to change the string
        public static string ConnectionString { get; } = "Data Source=mssqlstud.fhict.local;Initial Catalog=dbi500862;User ID=dbi500862;Password=Mkw4PQHJeU;";
    }
}
