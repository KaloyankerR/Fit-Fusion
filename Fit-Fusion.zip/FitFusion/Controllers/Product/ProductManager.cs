﻿using DataAcess;
using ProductModel = Models.Product.Product;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controllers.Product
{
    public class ProductManager
    {
        public ProductDAO productDAO;

        public ProductManager(ProductDAO productDao)
        {
            productDAO = productDao;
        }

        public bool CreateProduct(ProductModel product) 
        { 
            return productDAO.CreateProduct(product); 
        }


    }
}
